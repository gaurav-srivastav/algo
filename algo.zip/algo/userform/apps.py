from django.apps import AppConfig


class UserformConfig(AppConfig):
    name = 'userform'
