from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib import auth

# Create your views here.
def signup(request):
    if request.method == 'POST':
        if request.POST['email'] != '':
                try:
                        user = User.objects.get(email=request.POST['email'])
                        return render(request, 'userform/signup.html',{'error':'Email already exist'})
                except User.DoesNotExist:
                        user = User.objects.create_user(request.POST['name'],email=request.POST['email'],dob=request.POST['dob'],phonenumber=request.POST['phonenumber'])
                        auth.login(request, user)
                        return redirect('welcome')
        else: 
                return render(request,'userform/signup.html',{'error':'email cant be left blank'})

    else:
        return render(request,'userform/signup.html')    
         